<?php

declare(strict_types=1);

namespace Ehaic\ServerPowerFilter;

use Ehaic\ServerPowerFilter\Filament\FilterAwareTable;
use Filament\Contracts\Plugin;
use Filament\Panel;
use Filament\Tables\Table;
use Illuminate\Support\HtmlString;

class ServerPowerFilterPlugin implements Plugin
{
    public const VERSION = '0.1.1';

    public function getId(): string
    {
        return 'server-power-filter';
    }

    public function register(Panel $panel): void
    {
        // Only the user (app) panel has the servers index; swapping the binding is harmless for other tables because
        // FilterAwareTable only acts when the Livewire component is ListServers.
        app()->bind(Table::class, FilterAwareTable::class);

        // Theme-proof selected state: some themes (Smoked Glass) paint every toggle button as a filled, glowing chip, so
        // a checked button looked identical to an unchecked one. Unchecked = neutral outline, checked = solid status
        // colour + check mark. !important on purpose, to beat theme rules.
        $panel->renderHook('panels::styles.after', static fn (): HtmlString => new HtmlString(self::css()));
    }

    public static function css(): string
    {
        $in = 'input.fi-fo-toggle-buttons-input[wire\\:model$="power_status.groups"]';
        $colors = ['running' => '#22c55e', 'starting' => '#f59e0b', 'stopping' => '#f97316', 'restarting' => '#38bdf8', 'offline' => '#f43f5e', 'other' => '#94a3b8'];
        $css = "{$in} + label{background:transparent!important;color:inherit!important;box-shadow:none!important;"
            . 'border:1px solid rgba(148,163,184,.5)!important;opacity:.75;font-weight:400!important;cursor:pointer}'
            . "{$in} + label:hover{opacity:1;border-color:rgba(148,163,184,.9)!important}"
            . "{$in}:checked + label{opacity:1;font-weight:600!important;color:#0b1220!important}"
            . "{$in}:checked + label::before{content:'\\2713\\00a0'}"
            . "{$in}:focus-visible + label{outline:2px solid currentColor;outline-offset:2px}";
        foreach ($colors as $key => $hex) {
            $css .= "{$in}:checked + label[for$=\"-{$key}\"]{background:{$hex}!important;border-color:{$hex}!important}";
        }

        return '<style data-server-power-filter>' . $css . '</style>';
    }

    public function boot(Panel $panel): void
    {
    }
}
