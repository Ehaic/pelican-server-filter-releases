<?php

declare(strict_types=1);

namespace Ehaic\ServerPowerFilter\Filament;

use App\Filament\App\Resources\Servers\Pages\ListServers;
use Filament\Tables\Table;

/**
 * ListServers::table() calls ->filters([...]) which REPLACES any filter registered earlier (Table::configureUsing
 * cannot add one). The container is told to build this subclass instead of Table; it appends the power filter
 * whenever the owning Livewire component is the servers index, and is a plain Table everywhere else.
 */
class FilterAwareTable extends Table
{
    public function filters(array $filters, \Filament\Tables\Enums\FiltersLayout | string | \Closure | null $layout = null): static
    {
        if ($this->getLivewire() instanceof ListServers) {
            $has = false;
            foreach ($filters as $f) {
                if (method_exists($f, 'getName') && $f->getName() === 'power_status') {
                    $has = true;
                }
            }
            if (!$has) {
                array_unshift($filters, PowerStatusFilter::make());
            }
        }

        return parent::filters($filters, $layout);
    }
}
