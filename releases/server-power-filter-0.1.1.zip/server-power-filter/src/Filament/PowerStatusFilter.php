<?php

declare(strict_types=1);

namespace Ehaic\ServerPowerFilter\Filament;

use Ehaic\ServerPowerFilter\Support\PowerGroup;
use Filament\Forms\Components\ToggleButtons;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\Indicator;
use Illuminate\Database\Eloquent\Builder;
use Throwable;

final class PowerStatusFilter
{
    public static function make(): Filter
    {
        return Filter::make('power_status')
            ->label('Power status')
            ->schema([
                ToggleButtons::make('groups')
                    ->label('Power status')
                    ->multiple()
                    ->inline()
                    ->options(PowerGroup::LABELS)
                    ->colors(PowerGroup::COLORS),
            ])
            ->query(static function (Builder $query, array $data): Builder {
                $groups = PowerGroup::sanitize($data['groups'] ?? []);
                if ($groups === []) {
                    return $query;
                }

                // Power state lives in Wings, not the database. Server::condition reads the 15 s cached status the
                // cards use too, so this adds no extra daemon calls beyond what the page already makes.
                $ids = (clone $query)->get()
                    ->filter(static fn ($server): bool => in_array(self::groupOf($server), $groups, true))
                    ->map(static fn ($server) => $server->getKey())
                    ->values()
                    ->all();

                return $query->whereIn($query->getModel()->getQualifiedKeyName(), $ids);
            })
            ->indicateUsing(static function (array $data): array {
                $groups = PowerGroup::sanitize($data['groups'] ?? []);
                if ($groups === []) {
                    return [];
                }
                $labels = array_map(static fn (string $g): string => PowerGroup::LABELS[$g], $groups);

                return [Indicator::make('Power: ' . implode(', ', $labels))->removeField('groups')];
            });
    }

    private static function groupOf(object $server): string
    {
        try {
            $condition = $server->condition;

            return PowerGroup::fromValue($condition instanceof \BackedEnum ? (string) $condition->value : null);
        } catch (Throwable) {
            return PowerGroup::OTHER;
        }
    }
}
