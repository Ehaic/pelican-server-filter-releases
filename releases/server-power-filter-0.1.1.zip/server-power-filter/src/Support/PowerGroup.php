<?php

declare(strict_types=1);

namespace Ehaic\ServerPowerFilter\Support;

/**
 * Pure mapping from a server's condition value (Pelican's ContainerStatus / ServerState string) to one of six
 * filter groups. No framework dependencies so it is unit-testable with plain PHP.
 */
final class PowerGroup
{
    public const RUNNING = 'running';
    public const STARTING = 'starting';
    public const STOPPING = 'stopping';
    public const RESTARTING = 'restarting';
    public const OFFLINE = 'offline';
    public const OTHER = 'other';

    /** Filter option value => label, in display order. */
    public const LABELS = [
        self::RUNNING => 'Running',
        self::STARTING => 'Starting',
        self::STOPPING => 'Stopping',
        self::RESTARTING => 'Restarting',
        self::OFFLINE => 'Offline',
        self::OTHER => 'Other',
    ];

    /** Filament colours per group (match the status badge colours on the cards). */
    public const COLORS = [
        self::RUNNING => 'success',
        self::STARTING => 'warning',
        self::STOPPING => 'warning',
        self::RESTARTING => 'info',
        self::OFFLINE => 'danger',
        self::OTHER => 'gray',
    ];

    /**
     * Group for a ContainerStatus value. Everything that is not clearly up/transitioning/off (paused, removing,
     * missing = node unreachable or in maintenance, installing, suspended, ...) lands in "other" so no server can
     * vanish from every filter choice.
     */
    public static function fromValue(?string $value): string
    {
        return match ($value) {
            'running' => self::RUNNING,
            'starting' => self::STARTING,
            'stopping' => self::STOPPING,
            'restarting' => self::RESTARTING,
            'offline', 'exited', 'created', 'dead' => self::OFFLINE,
            default => self::OTHER,
        };
    }

    /**
     * @param  list<string>  $selected  values from the filter form
     * @return list<string>             only known groups, deduplicated
     */
    public static function sanitize(mixed $selected): array
    {
        if (!is_array($selected)) {
            return [];
        }

        return array_values(array_unique(array_filter(
            $selected,
            static fn ($v): bool => is_string($v) && isset(self::LABELS[$v]),
        )));
    }
}
